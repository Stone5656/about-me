import random
import pygame

# 牌の値を整数にマッピングするディクショナリ
value_mapping = {
    "1": 1, "2": 2, "3": 3, "4": 4, "5": 5, 
    "6": 6, "7": 7, "8": 8, "9": 9, 
    "東": 10, "南": 11, "西": 12, "北": 13, 
    "白": 14, "發": 15, "中": 16
}
def cpu_turn_action(cpu_hand, cpu_river, deck):
    if deck:
        discarded_tile = cpu_play(cpu_hand)
        cpu_river.append(discarded_tile)
        
        new_tile_str = deck.pop()  # デッキから新しい牌を受け取る（文字列として）
        # 新しいタイルの属性を抽出
        type_, value = extract_tile_attributes(new_tile_str)
        # 新しいMahjongTileオブジェクトを作成
        new_tile = MahjongTile(type_, value, x_position, y_position)
        cpu_hand.append(new_tile)  # 新しい牌をCPUの手に追加
# 牌を整列するための比較関数
def tile_sort_key(tile):
    type_mapping = {"萬": 1, "筒": 2, "索": 3, "風": 4, "三元": 5}
    return type_mapping[tile.type], value_mapping[tile.value]

def extract_tile_attributes(tile_str):
    if tile_str in ["白三元", "發三元", "中三元"]:
        return "三元", tile_str[:-2]
    else:
        # 最後の文字をタイプとして、それ以外の文字を値として取得
        return tile_str[-1], tile_str[:-1]
# Step 2: CPUがランダムに牌を捨てる関数
def cpu_play(cpu_hand):
    discarded_tile = random.choice(cpu_hand)
    cpu_hand.remove(discarded_tile)
    return discarded_tile

def display_river(screen, tile_images, river_list, start_x, start_y, river_width, river_height,tile_size, max_tiles_per_row, rotation_angle=0, spread_direction='right_down'):
    x_position = start_x
    y_position = start_y
    tile_count = 0
    width = river_width
    height = river_height
    pygame.draw.rect(screen, (200, 200, 200, 128), pygame.Rect(start_x, start_y, width, height))
    if spread_direction == 'right_up':
        y_position = start_y
        x_position = start_x + 200 - tile_size[1]
    elif spread_direction == 'left_down':
        y_position = start_y + 320 - tile_size[0]
        x_position = start_x
    elif spread_direction == 'left_up':
        y_position = start_y + 200 - tile_size[1]
        x_position = start_x + 320 - tile_size[0]
    for tile in river_list:
        if tile_count >= max_tiles_per_row:
            if rotation_angle == 0:
                y_position += tile_size[1]  # 新しい行のY座標を設定
                x_position = start_x  # X座標をリセット
            elif rotation_angle == 90:
                x_position += tile_size[1]
                y_position = start_y + 320 - tile_size[0]
            elif rotation_angle == -90:
                x_position -= tile_size[1]
                y_position = start_y
            elif rotation_angle == 180:
                y_position -= tile_size[1]
                x_position = start_x + 320 - tile_size[0]
            tile_count = 0  # タイルカウントをリセット
        
        tile_image = pygame.transform.rotate(tile_images[str(tile)], rotation_angle)
        screen.blit(tile_image, (x_position, y_position))
        if rotation_angle == 0:
            x_position += tile_size[0]
        elif rotation_angle == 90:
            y_position -= tile_size[0]
        elif rotation_angle == -90:
            y_position += tile_size[0]
        elif rotation_angle == 180:
            x_position -= tile_size[0]
        tile_count += 1
def draw_tiles_and_hands():
    # タイルを新しい位置に描画
    for tile in player_hand:
        screen.blit(tiles_images_resized[str(tile)], (tile.rect.x, tile.rect.y))

    # 上側のCPUの手配
    x_position_top = (1200 - len(game_refactored.top_cpu) * spacing) / 2
    y_position_top = 0
    for _ in game_refactored.top_cpu:
        screen.blit(tiles_images_resized['裏牌'], (x_position_top, y_position_top))
        x_position_top += spacing
    x_position_left = 0
    y_position_left = (800 - len(game_refactored.left_cpu) * spacing) / 2
    rotated_tile_image = pygame.transform.rotate(tiles_images_resized['裏牌'], 90)

    for _ in game_refactored.left_cpu:
        screen.blit(rotated_tile_image, (x_position_left, y_position_left))
        y_position_left += spacing
    # 右側のCPUの手配
    x_position_right = 1200 - tile_size[1]
    y_position_right = (800 - len(game_refactored.right_cpu) * spacing) / 2
    rotated_tile_image = pygame.transform.rotate(tiles_images_resized['裏牌'], -90)

    for _ in game_refactored.right_cpu:
        screen.blit(rotated_tile_image, (x_position_right, y_position_right))
        y_position_right += spacing

class MahjongTile:
    def __init__(self, type_, value, x=40, y=60, width=60, height=90):
        self.type = type_  # 萬子, 筒子, 索子, 風牌, 三元牌
        self.value = str(value)  # 値を文字列として保持
        self.rect = pygame.Rect(x, y, width, height)

    def __repr__(self):
        return f"{self.value}{self.type}"


class MahjongGameRefactored:
    def __init__(self):
        # 牌のタイプとその数値または名称
        self.tile_definitions = {
            '萬': list(range(1, 10)),
            '筒': list(range(1, 10)),
            '索': list(range(1, 10)),
            '風': ['東', '南', '西', '北'],
            '三元': ['中', '發', '白']
        }
        # 牌の山を生成
        self.tile_mountain = [MahjongTile(type_, value) for type_, values in self.tile_definitions.items() for value in values for _ in range(4)]
        random.shuffle(self.tile_mountain)
        self.cpu_hand = self.deal_tiles()  # CPUの手配を生成
       
        self.top_cpu = self.deal_tiles()
        self.right_cpu = self.deal_tiles()
        self.bottom_cpu = self.deal_tiles()
        self.left_cpu = self.deal_tiles()

    def shuffle_tiles(self):
        random.shuffle(self.tile_mountain)

    def deal_tiles(self, num=13):
        return [self.tile_mountain.pop() for _ in range(num)]
    def start_game():
    # ゲーム開始時の初期化や設定をここに記述
        pass

    class Player:
        def __init__(self, name):
            self.name = name
            self.hand = []
            self.discards = []

        def can_pon(self, tile):
            """ポンができるか判定するメソッド"""
            return self.hand.count(tile) >= 2

        def can_chi(self, tile):
            """チーができるか判定するメソッド（簡易版: 実際のルールはもう少し複雑）"""
            return tile.type in ['萬', '筒', '索'] and abs(self.hand[0].value - tile.value) <= 2

        def can_kan(self, tile):
            """カンができるか判定するメソッド"""
            return self.hand.count(tile) == 3

    class CPU(Player):
        def __init__(self, name):
            super().__init__(name)

        def decide_action(self, tile):
            """CPUがアクションを決定するメソッド（簡易版: 実際のルールはもう少し複雑）"""
            if self.can_pon(tile):
                return "pon"
            elif self.can_chi(tile):
                return "chi"
            elif self.can_kan(tile):
                return "kan"
            else:
                return "pass"
    def display_cpu_hand(self, cpu):
        for index in range(len(cpu.hand)):
            x_position = index * self.tile_size[0]  # tile_sizeが(x, y)のタプルであることを仮定
            y_position = 0  # 適切なY座標を設定してください
            screen.blit(self.images['裏牌'], (x_position, y_position))

    def display_discards(self, player):
        for index, tile in enumerate(player.discards):
            x_position = index * self.tile_size[0]
            y_position = self.screen_height - self.tile_size[1]  # screen_heightはウィンドウの高さを示す変数として仮定
            tile_image = self.images[f"{tile.value}{tile.type}"]
            screen.blit(tile_image, (x_position, y_position))
    def display_wall(self):
        for index in range(len(self.wall)):
            x_position = index * self.tile_size[0]
            y_position = 0  # 適切なY座標を設定してください
            screen.blit(self.images['裏牌'], (x_position, y_position))

    def discard_tile(self, player):
        discarded_tile = random.choice(player.hand)
        player.hand.remove(discarded_tile)
        player.discards.append(discarded_tile)


    def pon_action(self, player, tile):
        """ポンのアクションを実行するメソッド"""
        matching_tiles = [t for t in player.hand if t == tile]
        for t in matching_tiles:
            player.hand.remove(t)


    def chi_action(self, player, tile):
        """チーのアクションを実行するメソッド"""
    # 実際のルールに基づいてチーの処理を追加


    def kan_action(self, player, tile):
        """カンのアクションを実行するメソッド"""
        matching_tiles = [t for t in player.hand if t == tile]
        for t in matching_tiles:
            player.hand.remove(t)

    def tsumo_action(self, player):
        """ツモのアクションを実行するメソッド"""
        drawn_tile = self.wall.pop(0)
        player.hand.append(drawn_tile)
    

    def ron_action(self, player, tile):
        """ロンのアクションを実行するメソッド"""
        player.hand.append(tile)


        


game_refactored = MahjongGameRefactored()
game_refactored.shuffle_tiles()
dealt_tiles_refactored = game_refactored.deal_tiles()

dealt_tiles_refactored



import pygame

# pygameの初期化
pygame.init()

pygame.init()
screen = pygame.display.set_mode((1200, 800))
pygame.display.set_caption("麻雀")

tile_size = (40, 60)  # 幅40ピクセル、高さ60ピクセル

max_tiles_per_row = 8
# 麻雀のデッキを作成
deck = [
    "1萬", "2萬", "3萬", "4萬", "5萬", "6萬", "7萬", "8萬", "9萬",
    "1筒", "2筒", "3筒", "4筒", "5筒", "6筒", "7筒", "8筒", "9筒",
    "1索", "2索", "3索", "4索", "5索", "6索", "7索", "8索", "9索",
    "東風", "南風", "西風", "北風", 
    '白三元','發三元','中三元',
] * 4  

random.shuffle(deck)

river = []
# Step 1: CPUの河を作成
right_cpu_river = []
top_cpu_river = []
left_cpu_river = []

def load_and_resize_images(tile_names, tile_size):
    images = {}
    for name in tile_names:
        extension = 'png' if name != '裏牌' else 'jpg'
        images[name] = pygame.transform.scale(pygame.image.load(f'img/{name}.{extension}'), tile_size)
    return images

tile_names = [
    "1萬", "2萬", "3萬", "4萬", "5萬", "6萬", "7萬", "8萬", "9萬",
    "1筒", "2筒", "3筒", "4筒", "5筒", "6筒", "7筒", "8筒", "9筒",
    "1索", "2索", "3索", "4索", "5索", "6索", "7索", "8索", "9索",
    "東風", "南風", "西風", "北風", 
    '白三元','發三元','中三元',
    '裏牌'
]

tiles_images_resized = load_and_resize_images(tile_names, tile_size)

def draw_cpu_hands(screen, tiles_images_resized, game_refactored, tile_size, spacing):
    # 上側のCPUの手配
    x_position_top = (1200 - len(game_refactored.top_cpu) * spacing) / 2
    y_position_top = 0
    for _ in game_refactored.top_cpu:
        screen.blit(tiles_images_resized['裏牌'], (x_position_top, y_position_top))
        x_position_top += spacing
    
    # 左側のCPUの手配
    x_position_left = 0
    y_position_left = (800 - len(game_refactored.left_cpu) * spacing) / 2
    rotated_tile_image = pygame.transform.rotate(tiles_images_resized['裏牌'], 90)

    for _ in game_refactored.left_cpu:
        screen.blit(rotated_tile_image, (x_position_left, y_position_left))
        y_position_left += spacing

    # 右側のCPUの手配
    x_position_right = 1200 - tile_size[1]
    y_position_right = (800 - len(game_refactored.right_cpu) * spacing) / 2
    rotated_tile_image = pygame.transform.rotate(tiles_images_resized['裏牌'], -90)

    for _ in game_refactored.right_cpu:
        screen.blit(rotated_tile_image, (x_position_right, y_position_right))
        y_position_right += spacing


# 画面の更新
screen.fill((255, 255, 255))
x_position = 50
y_position = 100
spacing = 40

draw_cpu_hands(screen, tiles_images_resized, game_refactored, tile_size, spacing)
# 1. 自分の手配の牌のリストを取得
player_hand = game_refactored.bottom_cpu
top_cpu_hand =game_refactored.top_cpu
right_cpu_hand=game_refactored.right_cpu
left_cpu_hand = game_refactored.left_cpu

# 2. 牌のリストに基づいて、画面の下側に牌の画像を配置
x_position_player = (1200 - len(player_hand) * tile_size[0]) / 2  # 画面の中央に配置
y_position_player = 800 - tile_size[1]  # 画面の下側に配置

for tile in player_hand:
    tile.rect.x = x_position_player  # タイルオブジェクトのrectプロパティを更新
    tile.rect.y = y_position_player  # タイルオブジェクトのrectプロパティを更新
    screen.blit(tiles_images_resized[str(tile)], (tile.rect.x, tile.rect.y))
    x_position_player += tile_size[0]

pygame.display.flip()

# ゲームループ
turn_order = ["player", "right_cpu", "top_cpu", "left_cpu"]
current_turn_index = 0
current_turn = 'player'

running = True
dragging_tile = None
dragging = False
BACKGROUND_COLOR = (255, 255, 255)  # 白色
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_x, mouse_y = pygame.mouse.get_pos()
    
        # プレイヤーの手配内のすべての牌をチェック
            for tile in player_hand:
                if tile.rect.collidepoint(mouse_x, mouse_y):
                    print(f"Tile clicked: {tile}")
                    dragging = True
                    dragging_tile = tile

        if event.type == pygame.MOUSEMOTION and dragging:
            mouse_x, mouse_y = pygame.mouse.get_pos()
            dragging_tile.rect.x = mouse_x - dragging_tile.rect.width // 2
            dragging_tile.rect.y = mouse_y - dragging_tile.rect.height // 2
    
        # 画面をクリア（背景色で塗りつぶし）
            screen.fill(BACKGROUND_COLOR)
            
        # 河の表示
            pygame.draw.rect(screen, (200, 200, 200, 128), pygame.Rect(440, 500, 320, 200))

            x_position_river = 440
            y_position_river = 500
            tile_count = 0

            for tile in river:
                if tile_count >= max_tiles_per_row:
                    y_position_river += tile_size[1]  # 新しい行のY座標を設定
                    x_position_river = 440  # X座標をリセット
                    tile_count = 0  # タイルカウントをリセット
                
                screen.blit(tiles_images_resized[str(tile)], (x_position_river, y_position_river))
                x_position_river += tile_size[0]
                tile_count += 1
    
        # タイルを新しい位置に描画
            for tile in player_hand:
                screen.blit(tiles_images_resized[str(tile)], (tile.rect.x, tile.rect.y))

                x_position_top = (1200 - len(game_refactored.top_cpu) * spacing) / 2
                y_position_top = 0
        
            draw_tiles_and_hands()


# 右側のCPUの河を描画
        display_river(screen, tiles_images_resized, right_cpu_river, 200, 240, 200, 320, tile_size, max_tiles_per_row, -90, spread_direction='right_up')

# 上側のCPUの河を描画
        display_river(screen, tiles_images_resized, top_cpu_river, 440, 100, 320, 200, tile_size, max_tiles_per_row, 180, spread_direction='left_up')

# 左側のCPUの河を描画
        display_river(screen, tiles_images_resized, left_cpu_river, 800, 240, 200, 320, tile_size, max_tiles_per_row, 90, spread_direction='left_down')
        if current_turn == 'player':


            for tile in player_hand:
                screen.blit(tiles_images_resized[str(tile)], (tile.rect.x, tile.rect.y))


            if event.type == pygame.MOUSEBUTTONUP and dragging:
                dragging = False

            # 河の領域を表すRectオブジェクト
                river_rect = pygame.Rect(440, 500, 320, 200)
    
            # 牌が河の領域にドロップされたかどうかを確認
                if river_rect.collidepoint(mouse_x, mouse_y):
                    river.append(dragging_tile)
                    player_hand.remove(dragging_tile)

                # 新しい牌を受け取る
                    if deck:
                        new_tile_str = deck.pop()  # デッキから新しい牌を受け取る（文字列として）
    
                # 新しいタイルの属性を抽出
                        type_, value = extract_tile_attributes(new_tile_str)
    
                # 新しいMahjongTileオブジェクトを作成
                        new_tile = MahjongTile(type_, value, x_position, y_position)  

                        player_hand.append(new_tile)  # 新しい牌をプレイヤーの手に追加
                        player_hand.sort(key=tile_sort_key)

                        x_position_player = (1200 - len(player_hand) * tile_size[0]) / 2  # 画面の中央に配置
                        y_position_player = 800 - tile_size[1]  # 画面の下側に配置
                        for tile in player_hand:
                            screen.blit(tiles_images_resized[str(tile)], (x_position_player, y_position_player))
                            tile.rect.x = x_position_player  # タイルオブジェクトのrectプロパティを更新
                            tile.rect.y = y_position_player  # タイルオブジェクトのrectプロパティを更新
                            x_position_player += tile_size[0]

                            current_turn = 'right_cpu'
                    
        elif current_turn == 'right_cpu':
            cpu_turn_action(right_cpu_hand, right_cpu_river, deck)
            print('a')
            current_turn = 'top_cpu'

        elif current_turn == 'top_cpu':
            cpu_turn_action(top_cpu_hand, top_cpu_river, deck)
            current_turn = 'left_cpu'

        elif current_turn == 'left_cpu':
            cpu_turn_action(left_cpu_hand, left_cpu_river, deck)
            current_turn = 'player'
    # 次のターンに移動
        current_turn_index = (current_turn_index + 1) % 4
    pygame.display.flip()
                        


pygame.quit()